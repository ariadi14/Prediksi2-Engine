from fast_pelangi_parser import FastPelangiParser
from v20_78_19_fixture_identity import resolve_fixture
from v20_78_17_end_to_end import EndToEndEngine

IMAGES=['/mnt/data/v2078_work/cur1.jpg','/mnt/data/v2078_work/cur2.jpg','/mnt/data/v2078_work/cur3.jpg','/mnt/data/v2078_work/cur4.jpg']

def test_parser_names():
    r=FastPelangiParser().replay(IMAGES)
    names={(f['home'],f['away']) for f in r['fixtures']}
    assert ('Hamilton Academical','Cowdenbeath') in names
    assert ('SK Kladno','Banik Ostrava') in names
    assert ('Boreham Wood','Everton U21') in names

def test_fuzzy_resolution():
    q={'competition':'SCOTLAND CHALLENGE CUP','home':'ilton Academical','away':'Cowdenbeath'}
    c=[{'competition':'SCOTLAND CHALLENGE CUP','home':'Hamilton Academical','away':'Cowdenbeath'}]
    r=resolve_fixture(q,c)
    assert r is not None and r['_resolution']['score']>=78

def test_e2e_synthetic_evidence():
    r=FastPelangiParser().replay(IMAGES)
    f=next(x for x in r['fixtures'] if x['home']=='Azerbaijan' and x['away']=='Tajikistan')
    key='|'.join(str(f.get(k,'')) for k in ('competition','home','away','match_date','kickoff'))
    ev={key:{'home_xg':1.55,'away_xg':0.72,'evidence_quality':0.8}}
    out=EndToEndEngine().run_fixtures([f],ev)
    assert out['results'][0]['prediction']['status']=='CALCULATED'
    assert out['results'][0]['visible_candidates']

def test_e2e_parser_count():
    r=EndToEndEngine().run_images(IMAGES)
    assert r['unique_fixtures']>=25
    assert r['time_filter_mode']=='MANUAL'

if __name__=='__main__':
    test_parser_names(); test_fuzzy_resolution(); test_e2e_synthetic_evidence(); test_e2e_parser_count(); print('V20.78.27 TEST PASS')
