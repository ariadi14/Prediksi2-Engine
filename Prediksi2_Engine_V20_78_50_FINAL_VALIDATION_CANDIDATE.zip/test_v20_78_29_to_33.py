import os,sys
from v20_78_29_provider_identity import ProviderAwareTeamResolver
from v20_78_30_fixture_resolution import resolve_fixture_id
from v20_78_32_evidence_probability import EvidenceProbabilityGate
from v20_78_33_end_to_end import V33Engine

def test_provider_identity_local_fallback():
 r=ProviderAwareTeamResolver(catalog=[{'name':'Union La Calera','aliases':['Unión La Calera']},{'name':'Universidad Catolica','aliases':['CD Universidad Catolica']}])
 assert r.resolve('ye Union La Calera')['status']=='RESOLVED_HIGH'

def test_fixture_gate_blocks_without_provider():
 assert resolve_fixture_id({'home':'A','away':'B'},None)['status']=='UNRESOLVED'

def test_probability_gate_requires_evidence():
 p=EvidenceProbabilityGate().predict('x',{'evidence_status':'MISSING'},[])
 assert p['status']=='INSUFFICIENT_DATA'

def test_replay_structure():
 paths=['/mnt/data/v2078_work/cur1.jpg','/mnt/data/v2078_work/cur2.jpg','/mnt/data/v2078_work/cur3.jpg','/mnt/data/v2078_work/cur4.jpg','/mnt/data/147483.jpg']
 r=V33Engine().run(paths)
 assert r['version']=='V20.78.33' and r['time_filter_mode']=='MANUAL' and r['unique_fixtures']>=25

if __name__=='__main__':
 test_provider_identity_local_fallback();test_fixture_gate_blocks_without_provider();test_probability_gate_requires_evidence();test_replay_structure();print('V20.78.29-33 TEST PASS')
