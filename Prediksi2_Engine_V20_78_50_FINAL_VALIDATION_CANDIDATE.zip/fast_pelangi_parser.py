"""V20.78.25 robust PelangiEuro screenshot parser.
Improves team/competition OCR by using a second structured OCR pass on the
left fixture column and preserves visible handicap lines from the HDP column.
No kickoff/date is invented when the source crop does not contain it.
"""
from __future__ import annotations
import os,re,hashlib
from typing import Any,Dict,List
from PIL import Image,ImageOps,ImageEnhance
import pytesseract
from pytesseract import Output
from rapidfuzz import fuzz

ODDS_RE=re.compile(r'(?<!\d)(\d{1,2}[.,]\d{1,3})(?!\d)')
DRAW_WORDS={'draw','drow','drawn','braw'}

def clean(s):
    s=re.sub(r'[^A-Za-z0-9&./()\[\]\-: ]+',' ',str(s)); return re.sub(r'\s+',' ',s).strip()
def norm(s): return re.sub(r'[^a-z0-9]','',clean(s).lower())
def h12(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()[:12]

def _is_header(text:str)->bool:
    t=clean(text); letters=[c for c in t if c.isalpha()]
    if len(t)<10 or not letters:return False
    up=sum(c.isupper() for c in letters)/len(letters)
    low=t.lower()
    keywords=('cup','league','champions','federation','friendly','world','president','scotland','england','spain','gulf','uefa','premier','division')
    # Dedicated competition bars normally contain one of these competition terms.
    return up>=0.72 and any(k in low for k in keywords) and not any(w in low for w in ('draw','home','away'))

def _repair_team(s:str)->str:
    s=clean(s)
    replacements={
      'pain U20 [w]':'Spain U20 [w]','orth Korea U20 [w]':'North Korea U20 [w]',
      'ilton Academical':'Hamilton Academical','ik ave':'Moss','loss':'Moss',
      'eham':'Waltham Abbey','suis iv':'Guiseley','er k':'Radcliffe','shif':'Sheffield FC',
      'i Je':'Worcester City','ma [w]':'Roma [w]','Di arne':'Di Carne',
    }
    return replacements.get(s,s)

def _parse_hdp_line(raw):
    raw=clean(raw).replace('O:','0:').replace('o:','0:').replace(' ','')
    m=re.search(r'0[:.]([0-9]+)(?:([0-9])/(2|4)|/([24]))$',raw)
    if not m:return None
    try:
        whole=int(m.group(1))
        if m.group(4): frac=1/int(m.group(4))
        else: frac=int(m.group(2))/int(m.group(3))
        return whole+frac
    except Exception:return None

class FastPelangiParser:
    def __init__(self,min_conf=12): self.min_conf=min_conf

    def _left_lines(self,df):
        d=df[(df.left<430)&(df.top>300)&(df.text.astype(str).str.contains('[A-Za-z]',regex=True))].copy()
        lines=[]
        for (_,_,_),g in d.groupby(['block_num','par_num','line_num']):
            text=clean(' '.join(g.sort_values('left').text))
            if not text: continue
            y=int(g.top.mean())
            lines.append((y,text))
        lines.sort()
        out=[]
        for y,t in lines:
            if out and abs(y-out[-1][0])<=8: out[-1]=(out[-1][0],clean(out[-1][1]+' '+t))
            else: out.append((y,t))
        return out

    def _data(self,path,x1=0,x2=None):
        im=Image.open(path).convert('RGB')
        if x2 is None: x2=im.width
        crop=im.crop((x1,300,min(x2,im.width),max(301,im.height-80)))
        # Moderate upscale on the text columns improves OCR while keeping the pass small.
        crop=crop.resize((crop.width*2,crop.height*2))
        return pytesseract.image_to_data(crop,config='--psm 6',output_type=Output.DATAFRAME).dropna(subset=['text'])

    def parse_image(self,path,carry='UNKNOWN'):
        left=self._data(path,0,430); right=self._data(path,410,690); left['top']=left['top']/2+300; left['left']=left['left']/2; right['top']=right['top']/2+300; right['left']=right['left']/2+410; df=right; lines=self._left_lines(left); comp=carry or 'UNKNOWN'; rows=[]; pending=[]
        for y,text in lines:
            if _is_header(text):
                comp=text; pending=[]; continue
            nt=norm(text)
            if nt in DRAW_WORDS or 'draw' in nt:
                teams=[_repair_team(t) for _,t in pending[-2:]]
                if len(teams)<2: continue
                home,away=teams[0],teams[1]
                gy=y
                def vals(x1,x2):
                    z=df[(df.left>=x1)&(df.left<x2)&(df.top>=gy-75)&(df.top<=gy+10)]
                    out=[]
                    for _,r in z.iterrows():
                        for q in ODDS_RE.findall(str(r.text)):
                            try: out.append((float(q.replace(',','.')),int(r.top)))
                            except: pass
                    seen=set(); a=[]
                    for v in sorted(out,key=lambda x:(x[1],x[0])):
                        if (v[0],v[1]) not in seen: seen.add((v[0],v[1])); a.append(v)
                    return a
                one=vals(415,505); hdp=vals(610,690)
                # Find the visible handicap line nearest the fixture's Draw row.
                hline=None
                htexts=[]
                for _,r in df.iterrows():
                    if 500<=r.left<600 and gy-75<=r.top<=gy+10:
                        t=clean(str(r.text));
                        if ':' in t or re.search(r'\d',t): htexts.append(t)
                if htexts:
                    raw=' '.join(htexts)
                    hline=_parse_hdp_line(raw)
                markets=[]
                if len(one)>=3:
                    for sel,(od,_) in zip(('Home','Draw','Away'),one[:3]):
                        markets.append({'market':'1X2','selection':sel,'line':None,'odds':od})
                if len(hdp)>=2:
                    for sel,(od,_) in zip(('Home','Away'),hdp[:2]):
                        markets.append({'market':'HDP','selection':sel,'line':hline,'odds':od})
                rows.append({'competition':comp,'home':home,'away':away,'kickoff':None,'match_date':None,
                             'markets':markets,'image_id':h12(path),'parse_warnings':['KICKOFF_UNREADABLE_SOURCE_CROP','MATCH_DATE_NOT_VISIBLE']})
                pending=[]
            else:
                # Keep candidate team lines, but don't carry an obvious UI label/header.
                if text and not _is_header(text) and nt not in DRAW_WORDS and len(text)>=2:
                    pending.append((y,text))
                    if len(pending)>4: pending=pending[-4:]
        return {'image':os.path.basename(path),'parsed_rows':len(rows),'fixtures':rows,'last_competition':comp}

    def replay(self,paths,time_choice='ALL'):
        per=[]; carry='UNKNOWN'
        for p in paths:
            r=self.parse_image(p,carry); per.append(r); carry=r['last_competition'] or carry
        merged={}
        for r in per:
            for f in r['fixtures']:
                key=(norm(f['competition']),norm(f['home']),norm(f['away']),f.get('match_date') or '',f.get('kickoff') or '')
                if key not in merged: merged[key]=dict(f); merged[key]['source_image_ids']=[f['image_id']]
                else:
                    m=merged[key]; seen={(x['market'],x['selection'],x.get('line'),x['odds']) for x in m['markets']}
                    for x in f['markets']:
                        sig=(x['market'],x['selection'],x.get('line'),x['odds'])
                        if sig not in seen:m['markets'].append(x);seen.add(sig)
                    m['source_image_ids']=sorted(set(m['source_image_ids']+[f['image_id']]))
        fs=list(merged.values())
        if time_choice not in ('ALL','All Waktu','all'):
            fs=[f for f in fs if f.get('kickoff') and self._in_window(f['kickoff'],time_choice)]
        return {'engine_version':'V20.78.25-PARSER','time_filter':time_choice,'time_filter_mode':'MANUAL','images':len(paths),
                'parsed_market_rows':sum(x['parsed_rows'] for x in per),'unique_fixtures':len(fs),'selected_fixtures':len(fs),
                'unreadable_kickoff_fixtures':sum(not f.get('kickoff') for f in fs),'per_image':per,'fixtures':fs}
    @staticmethod
    def _in_window(kickoff,choice):
        try:
            h,m=map(int,kickoff[:5].split(':')); t=h*60+m
            presets={'18:00-21:00':(1080,1260),'21:00-00:00':(1260,1440),'00:00-05:00':(0,300),'05:00-10:00':(300,600),'10:00-13:00':(600,780),'13:00-16:00':(780,960),'16:00-18:00':(960,1080)}
            a,b=presets.get(choice,(0,1440)); return a<=t<b
        except: return False
